public interface Associated {
    void addAssociatedEnd(Associated end);

    boolean equals(Object o);
}
