package com.oocourse.uml1.configs;

/**
 * 版本信息
 */
public abstract class Version {
    public static final String GROUP_ID = "Object Oriental Course Group";
    public static final String ARTIFACT_ID = "UML Homework Official Package";
    public static final String VERSION_ID = "1.0.0-raw";
}
